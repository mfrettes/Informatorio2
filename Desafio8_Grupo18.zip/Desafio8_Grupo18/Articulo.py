from Comentario import Comentario
import datetime

class Articulo:
    id_articulo = 0
    articulos = []

    def __init__(self, id_usuario=0, titulo="", resumen="", contenido_articulo="", imagen="", estado=""):
        self.__class__.id_articulo += 1
        self.id_articulo = Articulo.id_articulo
        self.id_usuario = id_usuario
        self.titulo = titulo
        self.resumen = resumen
        self.contenido_articulo = contenido_articulo
        self.fecha_publicacion = datetime.datetime.now()
        self.imagen = imagen
        self.estado = estado
        self.comentarios = []

    def registrar_comentario(self):
        return Comentario(self.id_articulo, self.id_usuario).comentar()

    def registrar_articulo(self):
        self.titulo = input("Ingrese el titulo del articulo: ")
        self.resumen = input("Ingrese el resumen del articulo: ")
        self.contenido_articulo = input("Ingrese el contenido del articulo: ")
        self.imagen = input("Ingrese la imagen: ")
        self.estado = input("Ingrese el estado: ")

        add_first_comment = input(
            "Deseas hacer el primer comentario?: (si o no) ")

        if (add_first_comment.lower() == "si"):
            self.comentarios.append(self.registrar_comentario())

        self.articulos.append(self.__dict__)

    def lista_articulos(self):
        if (self.id_usuario == 0):
            return "Usuario no logueado"
        return self.articulos

    def lista_comentarios_por_articulo(self, id_articulo):
        print(id_articulo)
        print(self.articulos)
        for item in self.articulos:
            print(item)
            print(item['comentarios'])
            if (item['id_articulo'] == id_articulo):
                return item['comentarios']
            return []
