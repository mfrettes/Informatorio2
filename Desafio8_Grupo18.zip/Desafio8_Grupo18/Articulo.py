class Articulo:
    def __init__(self, id_articulo, id_usuario, titulo, resumen, contenido_articulo, fecha_publicacion, imagen, estado):
        self.id_articulo = id_articulo
        self.id_usuario = id_usuario
        self.titulo = titulo
        self.resumen = resumen
        self.contenido_articulo = contenido_articulo
        self.fecha_publicacion = fecha_publicacion
        self.imagen = imagen
        self.estado = estado
