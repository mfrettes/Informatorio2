from Usuario import Usuario

class Colaborador(Usuario):
    def __init__(
        self,
        usuario
    ):
        super().__init__(
			id_usuario=usuario.id_usuario,
            nombre=usuario.nombre,
            apellido=usuario.apellido,
            telefono=usuario.telefono,
            username=usuario.username,
            email=usuario.email,
            contrasena=usuario.contrasena,
            fecha_registro=usuario.fecha_registro,
            avatar=usuario.avatar,
            estado=usuario.estado,
            is_online=usuario.is_online
        )
        self.es_colaborador: bool = True

    def registrar_usuario(self):
        super().registrar_usuario()
    