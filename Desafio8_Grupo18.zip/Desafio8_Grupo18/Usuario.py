class Usuario:
    def __init__(
        self,
        id_usuario,
        nombre,
        apellido,
        telefono,
        username,
        email,
        contrasena,
        fecha_registro,
        avatar,
        estado,
        is_online,
    ):
        self.id_usuario = id_usuario
        self.nombre = nombre
        self.apellido = apellido
        self.telefono = telefono
        self.username = username
        self.email = email
        self.contrasena = contrasena
        self.fecha_registro = fecha_registro
        self.avatar = avatar
        self.estado = estado
        self.is_online = is_online

    def login_usuario(self):
        # Lógica de inicio de sesión
        pass

    def registrar(self):
        # Lógica de registro de usuario
        pass