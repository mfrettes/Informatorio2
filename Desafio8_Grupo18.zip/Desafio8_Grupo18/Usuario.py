class Usuario:
    users = []

    def __init__(
        self,
        id_usuario=0,
        nombre="",
        apellido="",
        telefono=0,
        username="",
        email="",
        contrasena="",
        fecha_registro="",
        avatar="",
        estado="",
        is_online=False,
    ):
        self.id_usuario = id_usuario
        self.nombre = nombre
        self.apellido = apellido
        self.telefono = telefono
        self.username = username
        self.email = email
        self.contrasena = contrasena
        self.fecha_registro = fecha_registro
        self.avatar = avatar
        self.estado = estado
        self.is_online = is_online

    def login_usuario(self, username, password):
        if (self.users.__len__() == 0):
            return False
        for user in self.users:
            if (user['username'] == username and user['contrasena'] == password):
                return user
            if (user['nombre'] == username and user['contrasena'] == password):
                return user
            return False

    def registrar_usuario(self):
        for info in self.__dict__:
            if (info == "" or info == 0):
                return
        self.users.append(self.__dict__)
