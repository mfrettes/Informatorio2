import datetime
from Colaborador import Colaborador
from Publico import Publico
from Usuario import Usuario
from Articulo import Articulo
from Comentario import Comentario

def user_info():
    nombre = input("Nombre: ")
    apellido = input("Apellido: ")
    telefono = input("Teléfono: ")
    username = input("Username: ")
    email = input("Email: ")
    contrasena = input("Contraseña: ")
    fecha_registro = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    avatar = input("Avatar: ")
    estado = input("Estado: ")
    is_online = input("Online (Sí/No): ").lower() == 'si'
    generated_id = generar_id()

    return Usuario(generated_id, nombre, apellido, telefono, username, email, contrasena, fecha_registro, avatar, estado, is_online)


def is_user_type_valid(user_type):
    if user_type == 1:
        return 'colaborador'
    if user_type == 2:
        return 'publico'
    if user_type >= 3:
        return False

def registrar_usuario(usuario=Usuario()):
    registered_user_type = None
    if usuario.id_usuario == 0:
        registered_user_info: Usuario = user_info()
    if usuario.id_usuario > 0:
        registered_user_info = usuario

    tipo_usuario = input(
        "Tipo de usuario (1 para colaborador, 2 para público): ")  # 2

    if is_user_type_valid(int(tipo_usuario)) == False:
        print("Opcion invalida. Por favor elegir un tipo de usuario valido.")
        registrar_usuario(registered_user_info)
        return

    if usuario.id_usuario >= 0 or is_user_type_valid(int(tipo_usuario)) == 'publico':
        registered_user_type = Publico(registered_user_info)

    if is_user_type_valid(int(tipo_usuario)) == 'colaborador':
        registered_user_type = Colaborador(registered_user_info)
        
    if hasattr(registered_user_type, "es_colaborador"):
        contrasena_admin = input("Contraseña de administrador: ")
        if contrasena_admin != 'admin':
            print("Contraseña incorrecta. Registrandose como publico")
            registrar_usuario(registered_user_info)
            return

    registered_user_type.registrar_usuario()
    registered_user_info = None
    registered_user_type = None

logged_user = False

def login():
    login_user_name = input("Ingrese su user name o su nombre: ")
    login_password = input("Ingrese su login password: ")
    global logged_user
    logged_user = Usuario().login_usuario(login_user_name, login_password)
    if logged_user == False:
        print("Usuario o contrasena incorrectos")
        return
    menu_de_opciones()

def menu_principal():
    while True:
        print("----- MENÚ PRINCIPAL -----")
        print("1. Loguearse")
        print("2. Registrarse")
        print("3. Salir")
        opcion: str = input("Ingrese su opción: ")
        if opcion == '1':
            login()
        elif opcion == '2':
            registrar_usuario()
        elif opcion == '3':
            print("Hasta luego!")
            break
        else:
            print("Opción inválida. Intente nuevamente.")

def menu_de_opciones():
    print("----- QUÉ DESEA HACER? -----")
    print("1. Crear o ver un artículo(s)")
    print("2. Comentar un artículo o ver sus comentarios")
    print("3. Salir")
    opcion: str = input("Ingrese su opción: ")
    if opcion == '1':
        crear_articulo()
    elif opcion == '2':
        crear_comentario()
    elif opcion == '3':
        logged_user = False
        return
    else:
        print("Opción inválida. Intente nuevamente.")
    menu_principal()
    
def crear_articulo():
    try:
        is_type_colaborador = logged_user['es_colaborador']
    except:
        is_type_colaborador = False
    while True:
        print("----- CREAR ARTICULO -----")
        print("1. Crear articulo") if is_type_colaborador else print("1. Crear articulo (NO TIENE PERMISOS PARA ESTA OPCION)")
        print("2. Ver articulos")
        print("3. Volver al menu anterior")
        opcion: str = input("Ingrese su opción: ")
        if opcion == '1' and is_type_colaborador:
            Articulo(logged_user['id_usuario']).registrar_articulo()
            print("Articulo registrado con exito \n")
        elif opcion == '2':
            print(Articulo(logged_user['id_usuario']).lista_articulos())
        elif opcion == '3':
            break
        else:
            print("Opción inválida. Intente nuevamente.")
    menu_de_opciones()

def crear_comentario():
    lista_articulos = Articulo(logged_user['id_usuario']).lista_articulos()
    if (lista_articulos.__len__() == 0):
        print("No hay articulos")
        menu_de_opciones()
    print(lista_articulos)
    id_articulo = input("Seleccione el articulo que desea comentar o ver comentarios (por favor de ingresar el numero del articulo): ")
    articulo_encontrado = Articulo().lista_comentarios_por_articulo(id_articulo)
    while True:
        print("----- CREAR COMENTARIO -----")
        print("1. Crear comentario en el articulo seleccionado")
        print("2. Ver comentarios del articulo seleccionado")
        print("3. Volver al menu anterior")
        opcion: str = input("Ingrese su opción: ")
        if opcion == '1':
            nuevo_comentario = Comentario(logged_user['id_usuario'], id_articulo).comentar()
            articulo_encontrado.append(nuevo_comentario)
            print("Comentario registrado con exito \n")
            print(articulo_encontrado)
        elif opcion == '2':
            print(articulo_encontrado)
        elif opcion.lower() == '3':
            break
        else:
            print("Opción inválida. Intente nuevamente.")
    menu_de_opciones()

id_usuario = 0

def generar_id():
    global id_usuario
    id_usuario += 1
    return id_usuario

fecha_registro_admin = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if __name__ == "__main__":
    menu_principal()

