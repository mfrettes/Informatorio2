import datetime
from Colaborador import  Colaborador
from Publico import Publico
from Usuario import Usuario

def generar_id():
    # Lógica para generar un ID único
    pass

def user_info():
    nombre = input("Nombre: ")
    apellido = input("Apellido: ")
    telefono = input("Teléfono: ")
    username = input("Username: ")
    email = input("Email: ")
    contrasena = input("Contraseña: ")
    fecha_registro = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    avatar = input("Avatar: ")
    estado = input("Estado: ")
    is_online = input("Online (Sí/No): ").lower() == 'si'
    id = generar_id()

    return Usuario(id, nombre, apellido, telefono, username, email, contrasena, fecha_registro, avatar, estado, is_online)


def is_user_type_colaborador(user_type):
    if user_type == 1:
        return True
    if user_type >= 3:
        return False

def is_user_type_publico(user_type):
    if user_type == 2:
        return True
    if user_type >= 3:
        return False


def registrar_usuario_publico(registered_user_info):
    public = Publico(registered_user_info)
    public.registrar_publico()


def registrar_usuario():
    registered_user_info = user_info()
    tipo_usuario = input("Tipo de usuario (1 para colaborador, 2 para público): ")

    if not is_user_type_colaborador(int(tipo_usuario)):
        print("Opcion invalida. Favor volver a registrarse.")
        registrar_usuario()
        return

    if is_user_type_publico(int(tipo_usuario)):
        registrar_usuario_publico(registered_user_info)

    if is_user_type_colaborador(int(tipo_usuario)): 
        contrasena_admin = input("Contraseña de administrador: ") 
        if contrasena_admin != 'admin':  
            print("Contraseña incorrecta. Registrándose como usuario público.")
            registrar_usuario_publico(registered_user_info)
            print("Usuario registrado con éxito")
            return
        colaborador = Colaborador(registered_user_info)
        colaborador.registrar_colaborador()

    print("Usuario registrado con éxito")


def login():
    # Lógica de inicio de sesión
    pass

def menu_principal():
    while True:
        print("----- MENÚ PRINCIPAL -----")
        print("1. Loguearse")
        print("2. Registrarse")
        print("3. Salir")
        opcion:str = input("Ingrese su opción: ")
        if opcion == '1':
            login()
        elif opcion == '2':
            registrar_usuario()
        elif opcion == '3':
            break
        else:
            print("Opción inválida. Intente nuevamente.")
            
fecha_registro_admin = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")            
user_admin =  Usuario(
        id_usuario="1",
        nombre="Admin",
        apellido="Admin",
        telefono="123456789",
        username="admin",
        email="admin@example.com",
        contrasena="admin123",
        fecha_registro=fecha_registro_admin ,
        avatar="avatar_admin.png",
        estado="activo",
        is_online=False
    )

# Crear usuario admin con una contraseña
admin = Colaborador(
   user_admin
)


if __name__ == "__main__":
    menu_principal()
