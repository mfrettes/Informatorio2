class Comentario:
    def __init__(self, id_comentario, id_articulo, id_usuario, contenido_comentario, fecha_hora, estado):
        self.id = id_comentario
        self.id_articulo = id_articulo
        self.id_usuario = id_usuario
        self.contenido_comentario = contenido_comentario
        self.fecha_hora = fecha_hora
        self.estado = estado
