import datetime

class Comentario:
    contenido_comentario = ""
    estado = ""
    id_comentario = 0
    
    def __init__(self, id_articulo=0, id_usuario=0):
        self.__class__.id_comentario += 1
        self.id_comentario = Comentario.id_comentario
        self.id_articulo = id_articulo
        self.id_usuario = id_usuario
        self.fecha_hora = datetime.datetime.now()

    def comentar(self):
        self.contenido_comentario = input("Ingrese el contenido del comentario: ")
        self.estado = input("Ingrese el estado: ")
        return self.__dict__
